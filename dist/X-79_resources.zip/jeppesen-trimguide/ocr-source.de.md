## Frontpage

X-79 One Design class



Onerseetacts
Rigg- Trimm- und Segelanleitung

Inhaltenngabe:

1. Einleitung
2. Bevor mon den Mast stellt
3. Mastfall einstellen
4. Einsetzen der Gummikelle
5. Einstellen der Unterwonten
6. Einstellen der Oberweilten
7. Einstellen der Mittelwanten
8. Riggabsicherung
9. Baummontage
10. Montage des Kickers
11. Umlenken der Fallen und Strecker
12. Umlenken der Gummileine und Backstagen
13. Die Anwendung der Backstagen
14. Die Anwendung des Achterstags
15. Die Anwendung der laufenden Unterwanten
16. Segelführung auf Regatten
17. Segelführung zum Tourensegeln

## Page 1

1. Um einen einfacheren Einstand in die X-79 zu ermöglichen, heben wir einen Trimmvorschlag ausgearbeitet, so wie wir die Saison 1979 gesegelt haben.
Diese Vorschläge sollen nicht els "Bibel" aufgefaßt werden, sondern als Einführung in eine neue, ungewohnte Klasse. Bei speziellen Fragen helfen wir Jederzeit gerne.

2. Bevor der Most gestellt wird, sollte man folgendes kontrollieren:

a. ob die Mastlaterne funktioniert und richtig herum aufgesetzt wurde, Für die Funktionskontrolleschließt man des Kabel, des unten aus dem Mast herauskommt, an eine Betterie, eventuell der aus dem Wagen, en.
b. ob der Windex ordentlich festgezogen und hinter der Laterne montiert ist. Wenn er auf der Laterne festgeschraubt wird, erreicht des Licht die Reflektoren nicht.
c. Alle Fellen sollen so durchgestzt und engeschlagen werden, daß sie bei gestelltem Mast zu erreichen sind.
d. Alle Wenten und Stegen sollen lt. Zeichnung auf Seite angeschlagen werden. Die Befestigungebeschläge für die Bockstagen und laufende Untervanten müssen kontrolliert werden.
Die Bolzen in den Salingen müssen stramm angezogen werden. Die Enden müssen mit Tape oder ähnlich gesichert werden.
e. Der Mastkragen _muß_ über den Mast geschoben werden, bevor er gestellt wird.
f. Bevor der Mast nun gestellt wird, kontrolliert man die Spanner auf Gängigkeit und das kein Sand im Gewinde ist.
g. Die Mittelwanten müssen ganz locker sein, bis der Mast steht.

3. Wenn der Mast fest auf dem Mastfuß steht kenn der Mast geliefert werden. Ale erstes sollten die lautenden Unterwanten dichtgenommen werden, um den Most zu fixieren,
dann das Vorsteg anschlagen. Jetzt steht der Mast absolut sicher, und man kann die Vanten festmachen, die Unterwanten vorn und die Oberwanten achtern.  (Wir machen es umgekehrt, um die Fock dichter nehmen zu können. Anmerkung des Obersetzers) Nach unserer Erfahrung läuft das Boot die beste Höhe. wenn der Mesttoppice. 30 cm hinter dem Nastfuß liegt.
Zum Messen ein Gericht ans Großfall hängen und den Abstand zur Nut messen.

Während des Messens die Backstegen und laufende Unterwenten leicht dichtnehmen, die Vanten bleiben dabei lose.

4, Nun werden die Gummikeile in der Deckedurchführung montiert. Dies sollte möglichst so wie beschrieben gemacht werden, da sonst leicht die Gefahr besteht, daß der
Quertrimm des Mastes negativ beeinflußt wird.
a. Man stellt den mast in Ouerrichechtung gerade hin ..
(remaining of page lost in original scan)

## Page 2

.. die Relingsleiste hält. Bingestellt wird der Mast nun mit den Oberwanten, die Unterwanten, laufende Unterwanten und die Backetagen sind dabei sehr lose.
Die Oberrasten nicht stark anziehen, da man so leicht eine Stauchkurve in den Most zieht.

b. Wenn der Mast ganz gerade ist kann es sein, daß er nicht hundertprozentig genau in der Mastdurchführung steht.
Das hat aber nichts zu bedeuten, der Mast sollte in dieser Position festgekeilt werden, da er dann genau in der Mitte steht.
Die Gummikeile sollen den Längentrim nicht beeinflussen.
Die Gummikeile aussen so heruntergepreßt werden, daß sie um den Most herumliegen. Jetzt steht der Mast im Decksniveau fest, und seine Bewegung ist gedämpfter als
wenn er nicht festgekeilt wäre.

Bevor man nun das restliche Rigg trimmt ist es ratsam, die Mastmanschette zu montieren. Die kleine Öffnung der Manchette zeigt nach oben.
Es wird nun an der Steile, an der sie sitzen soll eine Markierung am Maat angebracht, und darauf, wie auch in die Mastnut, etwas Silikon gegeben.
Dann zieht man die Manschette, und beispielsweise 2cm Yachtleine, dicht und entfernt das verbleibende Silikon mit Aceton. Vorsicht: Aceton darf nicht mit
Fendern oder Skylights in Berührung kommen. Um den Kragen mit der Decksdurchführung zu vorbinden, schneidet man den Ûberstand des Kragenrs mit
einer Schere ab und verfährt dann genauso wie an Mast. Nur Silikon dürfte hier nicht notwendig sein.

5. Nun werden die Unterwanten gespannt. Es ist darauf zu achten, daß beide gleichmäßig gespannt sind, go daß der Mast en den Salingen kein "S" bildet.
Dies kann man kontrollieren, indem man von Achtern die Mutnut heraufschaut. Die Unterwanten werden sehr stramm gefahren, man soll auf ihnen "Gitarre spielen können"
Andererseits sollen sie nicht so stramm sein, daß man oie nicht noch relativ leicht mit einem Schraubenzieher ein Stück weiter spannen könnte.

6. Hiernach werden die Oberwanten getrimmt. Diese brauchen wir ja schon vorher, um den Mast quer auszurichten, aber die Spannung ist noch zufällig,
nur sind beide, wie die Unterwenton, auf gleicher Spannung.
Die Oberventen sollen spürbar loser stehen als die Unterwanten, was vielleicht etwas merkwürdig klingt. Aber die Sache ist ja die, daß man,
wenn man mit vollem Groß fährt, nicht verhindern kann, daß der Masttopp durch den Ruck des Segels etwas vegbiegt, und man daher dafür sorgen muß,
des der Teil des Mastes unter den Oberwenton eine querschiffs Kurve formt, die mit dem oberen Teil harmoniert. Dies erreicht man also durch lockere Oberwanten.

Es ist unmöglich, genau zu engen, wieviel mehr Lose die Oberwanten als die Unterwanten haben müssen - es ist nicht viel, aber deutlich fühlbar.

7. Men müssen wir auf die Salinge steigen, um die Zwischenwanten zu spannen.

Aus Sicherheitsgründen sollte man immer zwei Fallen benutzen, um

## Page 3

einen Mann in den Mast zu hieven - es kann passieren, daß der Spleiß zwischen Draht und Tauwerk aufgeht. Man sollte einen Schraubenschlüssell einen
Schraubenzieher und etwas Klebeband mitnehmen.

Es ist so gedacht, daß die Zwischenwanten erst wirksam werden, wenn man mit vollem Segeldruck und optimaler Krängung. d.h. 20-25 Grad, segelt.

Die Mittelwanten sollten also nicht auf Spannung stehen, solange das Schiff im Hafen liegt. Man sollte sie in ihrer Mitte in einem Kreis von 10-15 cm Durchmesser bewegen können.

8. Abschließend werden alle Splinte gesichert, Kontermuttern nachgezogen und mit Tesaband umklebt.

9. Die Montage des Baumes geht ganz einfach, es muß darauf geachtet werden, daß die Nylonscheibe oberhalb des Baumbeschlages in der Haftung sitzt,
wenn man den Sicherungebolzen mit den Reffhaken durchschiebt.

10. Der Kicker wird am Baumbeschlag angebolzt, und zwar mit dem dünneren Ende nach oben. Das dickere Ende wird am dafür vorgesehenen Mastbeschlag montiert.
Man muß darauf achten, daß der Baum, wenn der Kickerrutscher im vordersten Loch ist, etwa waagerecht ist. 
Wenn das nicht der Fall ist, löst man die Schrauben der Kickerschiene etwas und stellt den Baum richtig hin. Dann zieht man die Schrauben möglichst stark wieder fest.

11. Die Fallumlenkblöcke werden an den Augbolzen um den Mastfuß montiert, und zwar die beiden Doppelblöcke vorn, ein Doppel und ein Einzelblock dahinter,
und ein kleiner Einzelblock in der Mitte. Da die vorderen Augbolzen mit einem Drahtstropp nach unten zum Mast gespannt werden, kommen dort die Leinen
mit dem größten Zug drauf: Groß- und Fockfall und die beiden Reffleinen. Der Cunningham kommt auf die Backbord am Mast angenietet Rolle.
Spifall, Toppnant und Unterliekstrecker gehen durch die Blöcke dahinter. Der Baumniederholer wird durch den kleinen Block in der Mitte nach achtern umgelenkt.
Nun können auch die Großschot und die Maststropps für die Fallen montiert werden.

1 12. Nun sind wir bald segelklor, es müssen nur noch die Gummis angebracht werden, die die Lee-Backstagen daran hindern sollen, während der Wende oder Halse unter den Großbaum zu kommen.

Ca, 2,20m über Deck Ist am Achterstag ein Auge angebracht, durch welches das Gummi gezogen wird. Die Enden werden nun entweder an den Endblöcken der Backstagen angeknotet,
und zwar so, daß das Gummi stramm ist, wenn beide Stegen durchgesetzt sind, oder aber man läßt zwei kleine Schäkel über die Backstagen laufen und befestigt das
Gummi daran, su daß sie ebenfalls stramm sind.

Bevor man nun in See sticht, sollte man sich aber den Rest diesen kleinen Heftes noch durchlesen.

13.l Backstagen: Die Backstagen sind dazu da, den Teil des Mastes nach hinten zu halben, an dem das Vorstag mit der Genua Ihn nach vorne zieht.
Das Vorstag wird also mit Hilfe der Backstagen durchgesetzt, damit

## Page 4

die Genuafacon stimmt.

Sobald es stärker als 4 m/sec weht, sollten die Backstagen benützt werden, nur auf der Luv-Seite natürlich, je stärker der Wind, um so strammer, falls nötig, mit der Genuaminsch.

Für jede Wende sollte man das Backsteg auf dem Abklemmer fahren, um die Genuaschot schon auf die Winsch legen zu können.

Außerdem werden die Backetstagen eingesetzt, wenn man nicht hart am Wind segelt. Hier kenn man es aber bis 5 m/sec lose lassen, und solange er nicht mit mehr als 10 m/sec weht,
kann man bei der Halse beide Backstagen loswerfen, die laufenden Unterwanten stabilisieren den Mast auereichend.

Wie sollte sen bei hartem Wind halsen?

Als erstes sollte man mödglichst schnell segeln, um die scheinbare Windgeschwindigkeit herabzusetzen. Das Lee-Backstag wird dichtgenommen, man nimmt in Kauf,
daß das Großsegeo nicht mehr voll steht. Während der eigentlichen Halse fiert man langsam des bisherige Luv-Backstag. Dann nimmt man das neue Luv-Back-steg dicht.

Das ist die richtige Methode, wenn man die Boots- und Mast-eigenschaften kennt.

Die sicherte Methode ist natürlich. das Großsegel doppelt oder dreifach zu reffen, so daß das Segel unter des Bocksteg hindurchgeht.

Eine dritte Möglichkeit bei mehr als 6 Windetticken zu halsen, besteht darin, das Luv-Backsteg etwas zu fieren und während der Halse das neue Luv-Backstag dichtzunehmen.
Danach muß sofort das Lee-Backetag gefiert werden. Bei dieser Manöverfolge besteht allerdings die Gefahr, das Achterliek oder eine Segellatte zu beschädigen.

WICHTIG!

14. Das Achtersteg wird gebraucht, um den Mast zu biegen. An der Kreuz mit vollem Groß sollte man das Achterstag so fahren, das ein deutlicher Ruderdruck spürbar ist.
Das gilt auch dann, wenn Cunningham und Minireff durchgesetzt sind und der Traveller ganz in Lee steht.

Man darf das Achterstag nicht soweit holen, daß das Großsegel Falten von der Baumnock zur Mastmitte wirft. Wann man fas Grußsegel einmal gerefft fährt,
gilt das selbe wie für das ungereffte Segel.

Wenn ein aber mit 2 oder 3 Reffs segelt, benötigt man das Achterstag, um den Mast in einer positiven Kurve zu halten, denn durch den Zug den Vorstages über
dem Großsegel wird der Mast in der Mitte nach achtete gebogen.

Wieweit man das Achtersteg holt ist Erfahrungssache, aber man soll den Mast lieber mehr als zu wenig biegen.

## Page 5

15. Die laufenden Unterwanten (Unterbackstagen) werden nur an der Kreuz und auf Am-Wind-Kursen gebraucht, wenn die Wellen so groß sind, daß das Boot stark arbeitet.

Debei beginnt der Mast zu "pumpen", das heißt, er biegt sich in der Welle vor und zurück. Dabei wird das Großsegel abgeflacht, gerade wenn man Profil braucht,
um mit Kraft durch die Welle zu kommen.

Um diese Bewegung zu verhindern, nimmt sen die Rutscher der laufenden Unterwanten  1.5m auf der Genuaschiene zurück und setzt die Talje dicht.

Wenn man am Anfang noch nicht sicher ist, ob man die Unterbackstagen einsetzen soll, nimmt man sie am besten nur etwa 40 cm zurück.
Denn übernehmen sie die Funktion von normalen achteren Unterwanten.

Der Vorteil besteht darin, das man die Unterbackstagen im Gegensatz zu achteren Unterwanten losen und das Großsegel auf Raumkursen voll suffieren.,
und sie erst bei Bedarf im Seegang dicht-nehmen kann. Bei glattem Wasser ist es möglich mit voller Mastkurve zu fahren.

WICHTIG:
Man darf natürlich vor einer Halse nicht vergessen, die laufenden Untervanten zu lösen.

16. Segelführung auf Regatten
Grundsätzlich sollte man versuchen, soviel Segelfläche wie möglich zu tragen, ohne daß das Boot mehr als 25 Grad krängt. Bei wenig Wind sollte man etwa 8 Grad Lage fahren.
Nur auf Vormwind-kursen soll das Boot ganz aufrecht gesegelt werden. Bei Leichtwind unter 2 m/sec (etwa 1-2 Beaufort) sollte man nach vorne trimmen,
um die benetzte Fläche zu verringern, sonst sitzt man möglichst im Cockpitbereich.

Nach unserer Erfahrung macht es sich bezahlt, die Genua so lange wie möglich zu fahren, wenn man eine hohe, steile Welle hat, um mit Kraft durchzufahren.

Bei glattem Wasser kann man früher auf die Fock wechseln, um eine etwas bessere Höhe zu fahren.

Der GroBsegeltrimm bongt natürlich stark davon ab, welches Vorsegel gefahren wird, aber man holt den Traveller niemals höher als Mitte Cockpit, außer bei
weniger als 2 m/sec, etwa 2 Beaufort..

Bei mehr Wind nimmt man den Unterliekstrecker dicht und trimmt die größte Profiltiefe ins erste Drittel.

Manchmal ist es von Vorteil, des Großsegel total flach zu machen, um möglichst viel Segelfläche fahren zu können. Dazu nimmt man Unterliekstrecker bzw. Minireff,
Cunninghem und Achtersteg. Gleichzeitig kann man mit den Baumniederholer experimentieren, um die Mastkurve noch zu erhöhen und das Großsegel extrem ab-zuflachen.
11••1 •:01 I I •• 'As 

Zuletzt .. (last part of line lost in scan)

## Page 6

2 m/sec (ce. 2 Beaufort) der SC-max-Spinnaker nicht gesegelt werden sollte. Der relativ schwache Wind kenn seine breiten Schultern nicht tragen.
Die Felge ist, daß dedurch der Spinnaker leichter einfällt.

17. Segelführung zum Tourensegeln
Wenn man sich des Segeln bequem machen möchte, oder seine Familie schönen will. solte man ab 4 m/sec (ca. 3 Beaufort) mit der Fock mogeln.
Wenn man sich die Arbeit mit den Backstagen ersparen will, refft man das Großsegel doppelt. Bei der Wende geht es dann gut frei. Etwa ab 5 m/sec (ca. 4 Beaufort)
kann man ganz ohne Fock, dafür mit vollem Groß auch sehr bequem segeln. An der Kreuz sollte man dann aber auf etwas Höhe verzichten.
Generall ist zu empfehlen, kleine Segel zu fahren, um des Boot ruhiger zu halten.

Im Vergleich mit normalen Fahrtenyachten wird es sich immer noch als sehr schnell erweisen.

Im übrigen: Sollten sich noch Fragen ergeben, rufe uns an oder schreibe an die Klassenvereinigung oder en uns von X-Yachts.

Mit Seglergrüßen

Lars und Niela Jeppesen 

## trim.jpg

2-19 Maat, gesehen bei etwa 20' Krängung unter der Voraussetzung. die Unt eeeee ten gleichmäßig mehr hart dicht eind.
Meattop 
Obermaat 
niveau 
Mittelvent ni 
O 
tt 
Decke 
niveau 
9 
Meettop-
Ob eeeee t 
niveee 
Kittelwant 
Decke niwea• 
dall 
1) Richtige» Mittelwant Rich eeeee Ob  2/Richtigen Mittelwent au lonae Oberwent 3:Richtigee Mittelwant au et aaaaaa Ob  ... — . — —. ei co iunem Mittelwent richtiges Ob  • -----  I— 5) au 1  Mittel- und Ob  .— . — —I. / 1 1 . ---- ...... ----.  --.. —iff / t -. ..—. ....-1■3.,..—....—. — — f to I J/ J . , . 46_ ez u a 11  Na st aaaaaa 94111 Kraue Mittelwent Mittelwant Mittelwant Mit aaaaa nt zu etrammee rieh aaaaa so lose» zu atramme Oberwant "Ob  Oberwant Oberwett ...— — . — ------. ---. ....--.-- t --- i 0 - - ........ ••der oben hoch • Olveoullnlen — — . - t t r-__. / 1.--. . ......I 

