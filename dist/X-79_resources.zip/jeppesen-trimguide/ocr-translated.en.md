## FrontPage

X-79 One Design class



Onerseetacts
Rigg- Trim and Sailing Instructions

Inhaltenngabe:

1 Introduction
2. Before mon represents the mast
3. Adjust mast rake
4. Insert the rubber trowel
5. Setting Unterwonten
6. Adjusting the Upper dwelt
7. Adjusting the center shrouds
8. Riggabsicherung
9. Harness Assembly
10. Mounting of Kickers
11. redirecting the traps and Strecker
12. redirecting the shock cord and backstays
13. The use of backstays
14. The application of the backstay
15. The application of the current lower shrouds
16 sails on regatta
17 sails for sailing tour

## Page 1

1. In order to enable an easier start into the X-79, we highlight a trim proposal elaborated, as we have sailed the season 1979th
These proposals should not be construed els "Bible", but as an introduction to a new, unfamiliar class. For specific questions, we can help at any time.

2. Before the wine is made, you should check the following:

a. whether the mast lamp works and the correct direction has been set up, for the function control If you connect the cable, the coming out of the mast down to a Betterie, possibly the out of the car, en.
b. whether the Windex properly tightened and is mounted behind the lamp. If it is screwed on the lamp, the light does not reach the reflectors.
c. All skins should be durchgestzt and close suggest that they can be reached at gestelltem mast.
d. All Wenten and webs should lt. Drawing will be posted on site. The Befestigungebeschläge for Bock days and ongoing Untervanten must be controlled.
The bolts in the spreaders to be pulled too tight. The ends must be secured with tape or similar.
e. The mast collar _must_ be pushed over the mast before it is asked.
f. Before the mast is now being made, one controls the tension for smooth and that's no sand in the threads.
g. The middle shrouds must be easily until the mast is.

3. If the mast is fixed to the mast mark the mast come. First among denominated lower shrouds should be densely taken to fix the new wine,
then hit the Vorsteg. Now the mast is completely safe, and you can fix the vant, the lower shrouds forward and aft upper shrouds. (We do the opposite, to take the jib tight can. Note the upper translator) In our experience, the boat runs the best height. when the Mesttoppice. 30 cm behind the Nastfuß.
hang to measure a dish to the main halyard and measure the distance to the groove.

During measurement tightly take the shoe webs and ongoing Unterwenten easily that vant remain loose.

4, Now the rubber wedges are mounted in the ceiling implementing. This should preferably be made as described, otherwise easily the risk that the
Lateral trimming of the mast is adversely affected.
a. It represents the mast in Ouerrichechtung straighter ..
(Remaining of page lost in original scan)

## Page 2

.. The railing bar keeps. the mast is binge one now with the cap shrouds, the lower shrouds, lower shrouds and running the cheek days are very loose.
The upper notches attract not strong because it so easily attracts a compression curve in the must.

b. If the mast is completely straight, it may be that it is not perfectly accurate in the mast guide.
That did not mean anything, the pole should be wedged in this position, because then it is exactly in the middle.
The rubber wedges are not to affect the Längentrim.
The rubber wedges outside so be heruntergepreßt that they lie around the new wine. Now the mast is fixed in the deck level, and its movement is damped as
if he had not wedged.

For example, prior to trim the remaining rig, it is advisable to mount the mast collar. The small opening of the cuff facing upward.
It will now be attached to the Steep, where it is to sit on a label mate, and how in the mast slot, where some silicone.
Then close and away draws the cuff, and for example, 2cm yachtrope, the remaining silicon with acetone. Caution: Acetone with
Fenders or skylights come into contact. To pre-bonding the collar with the deck passage, to cut the Ûberstand of Kragenrs with
a scissors and then proceeds as well as on mast. Only silicone should not be necessary here.

5. Now, the lower shrouds are tensioned. It is important to ensure that both are equally tensioned, go that the mast en the spreaders no "S" forms.
This can check it by looking up the Mutnut from aft. The lower shrouds are driven very tight, you should "play guitar" on them
On the other hand they should not be so tight that you could not oie still relatively slight tension with a screwdriver a bit further.

6. Hereinafter, trimmed the upper shroud. This we need already previously to align the mast transversely, but the tension is still random,
only are both how Unterwenton, at the same voltage.
The Oberventen are noticeably loose stand than the lower shrouds, which perhaps sounds a little odd. But the thing is indeed the, that,
if you go with a full size, can not prevent the masthead by the jerk of the sail vegbiegt something and we must therefore ensure
of the part of the mast under the Oberwenton formed an athwartships curve that harmonizes with the upper part. So this can be achieved by loose upper shrouds.

It is impossible to accurately narrow, much more lots must have the upper shrouds than the lower shrouds - it's not much, but clearly perceptible.

7. Men we must rise to the spreaders to tighten the intermediate shrouds.

For safety reasons you should always use two traps

## Page 3

a man to hoist the mast - it can happen that the splice between wire and rope rises. You should take a Schraubenschlüssell a
Screwdriver and take some tape.

It is intended that the intermediate shrouds only be effective when. With full sail pressure and optimum heel i.e. 20-25 degrees, sailing.

Means shrouds should therefore not be on voltage as long as the ship is in port. One should be able to move in the midst of a circle of 10-15 cm diameter.

8. Finally, all split pins are secured, tightened locknuts and umklebt with scotch tape.

9. The assembly of the tree is very simple, it must be ensured that the nylon washer sits above the tree fitting in adhesion,
when by pushing the Siche Runge bolts with Reffhaken.

10. The kicker is pinned to the boom fitting, with the thinner end upwards. The thicker end is mounted on dedicated mast fitting.
Care must be taken that the tree when the kicker rider in the front hole is approximately horizontally.
If that is not the case, it solves the screws of kickers rail slightly and represents the tree towards right. Then the screw as much as possible tightens again.

11. The Fallumlenkblöcke be mounted on the eyebolt to the mast base, and indeed the two double blocks forward, one double and one single block behind,
and a small single-block in the middle. Since the front eyebolts are tightened with a wire sling down to the mast, get there Linens
with the biggest train strikes: wholesale and jib halyard and two reefing lines. The Cunningham comes on the port side of the mast riveted role.
Spinnaker halyard, uphaul and outhaul go through the blocks behind. The vang is deflected by the small block in the center aft.
Now the mainsheet and the Maststropps can be mounted for the traps.

1 12. Now we are soon segelklor, it only need to be mounted, the rubber that should prevent the leeward backstay because the tack or jibe to get under the boom while.

Ca, 2.20 m above the deck If the backstay mounted an eye through which the rubber is pulled. The ends are then knotted at either the end blocks of the backstays,
in such a way that the rubber is tightly when both webs are enforced, or is allowed two small shackles pass over the backstays and secured the
Rubber mind su that they are also tight.

Now, before going to sea, but should the rest of this little booklet to read yet.

13.l backstays: The backstays are there to half, where the forestay with the Genoa draws him the part of the mast to the rear to the front.
The forestay is therefore enforced using the backstays so

## Page 4

the Genuafacon true.

Once more than 4 m / sec blows, the backstays should be used only on the windward side, of course, the stronger the wind, so as brisk, if necessary, with the Genuaminsch.

For each turn should drive the shoe web on the jammer, to put the genoa already on the winch can.

In addition, the Backetstagen be used if one is not sailing close to the wind. But here you mark it up to 5 m / sec loose can, and as long as he does not blow with more than 10 m / sec,
can casting of lots at the neck both backstays, the current lower shrouds stabilize the mast except-calibrating.

How should sen jibe in strong winds?

First you should sail mödglichst quickly to reduce the apparent wind speed. The Lee-runner is sealed taken, it is accepted,
that the Großsegeo is no longer full. During the actual throat slowly fiert the previous windward runner. Then you take the new Luv-back ridge tightly.

This is the correct method, if one knows the boat and masted properties.

The securing method is natural. the mainsail reefed double or triple, so that the sail pass under the trestle bridge.

A third possibility for more than 6 Overcomes ticking to jibe, is the windward shoe web to slacken somewhat and during throat tightly take the new windward runner.
Thereafter, the Lee-Backetag immediately should be eased. In this maneuver sequence creates the risk of damaging the leech or a batten.

IMPORTANT!

14. The aft bridge is needed to bend the mast. At the cross with full large should the backstay drive so that is a significant pressure on the rudder felt.
This applies even if Cunningham and Minireff are enforced and the traveler all stands in Lee.

One must not get so far that the mainsail is wrinkled by the Baumnock for fattening center the backstay. When you go fas reefed sails greeting once,
the same applies as for the ungereffte sailing.

When a but sails with 2 or 3 reefs, one needs the backstay in order to keep the mast in a positive curve, because by the train the forestay over
the mainsail mast is bent in the middle to stayed.

To what extent is the aft bridge is obsolete matter of experience, but one should prefer the mast bend over too little.

## Page 5

15. The current lower shrouds (lower backstays) are used only on the cross and to close-hauled course, when the waves are so great that the boat is working hard.

Debei starts the mast to "pump", that is, it bends in the shaft back and forth. Here, the mainsail is flattened, just when you need profile,
to come up with force through the shaft.

To prevent this movement, takes sen the rider of the current lower shrouds 1.5m on the Genoa rail and sets the tackle tight.

If one is not sure at first whether to use the lower backstays, one takes it best back only about 40 cm.
Because they assume the function of normal aft lower shrouds.

The advantage is that you fully suffieren sub backstays unlike aft lower shrouds loose and the mainsail to room rates.,
and it can tight-take at sea when required only. In smooth water, it is possible to drive at full mast curve.

IMPORTANT:
One must not forget to solve the current Untervanten course before a jibe.

16 sails on regatta
Basically you should try to carry as much sail area as possible without causing the boat heels over 25 degrees. With little wind should drive about 8 degrees location.
Only on downwind courses-boat is to be sailed fully upright. In light winds below 2 m / sec (about 1-2 Beaufort) you should trim forward,
to reduce the wetted area, otherwise you sit in the cockpit area as possible.

In our experience, it pays to ride the Genoa as long as possible, if you have a high, steep shaft to drive through with force.

In smooth water can be earlier change to the jib to drive a slightly better level.

Of course, the rough sail trim bongt strongly upon which headsail is moved, but not to bring the traveler never higher than center cockpit, except for
less than 2 m / sec, about 2 Beaufort ..

In stronger winds taking the outhaul tight and trim the greatest tread depth the first third.

Sometimes it is advantageous to make the mainsail completely flat in order to drive as much sail area can. This involves taking Outhaul or Minireff,
Cunninghem and aft web. At the same time, you can experiment with the boom vang to still increase the mast curve and the mainsail extremely off-zuflachen.
11 •• 1 • 01 I I •• 'As

Last .. (last part of line drawn in scan)

## Page 6

2 m / sec (ce. 2 Beaufort) the SC-max Spinnaker should not be sailed. The relatively weak wind mark not wearing his broad shoulders.
The rim is that dedurch the Spinnaker easily dream up.

17 sails for sailing tour
If you want to make the sailing comfortable, or will his family beautiful. you Solte from 4 m / sec (about 3 Beaufort) Bumble with the jib.
If one wants to avoid working with the backstays, reffi to the mainsail twice. At the turn it goes well free. From about 5 m / sec (about 4 Beaufort)
you can instead sail without jib, with full United also very convenient. At the Cross but you should waive some height.
Generall is recommended to take small sail to keep the boat quiet.

Compared with normal cruising yachts it will still prove to be very fast.

Incidentally: If there are still questions arise, give us a call or write to the Class Association or en us about X-Yachts.

With sailors greetings

Lars and Niela Jeppesen

## trim.jpg

2-19 Maat, seen in about 20 'heeling provided. the Unt eeeee th uniformly more hard dense eind.
Meattop
petty officer
level
Mittelvent ni
O
tt
blanket
level
9
Meettop-
Whether eeeee t
niveee
Kittel Want
Ceiling niwea •
dall
1) Correct "means Want Rich eeeee Whether 2 / Right Mittelwent au lonae Oberwent 3: Richtigee agents Want au et aaaaaa Whether ... -. - -. ei co iunem Mittelwent real Whether • ----- I- 5) au 1 Central and whether .-. - -I. / 1 1st ---- ---- ....... - .. -iff / T -. ..-. ....- 1 ■ 3., ..-....-. - - F to I J / J. ,. 46_ ez among others 11 st Na aaaaaa 94111 Kraue Mittelwent agents Want Want agents with aaaaa nt to etrammee Rich aaaaa so loose "to atramme upper Want" Whether Cap shroud upper Bet ...- -. -.. ------ --- ... . - .-- --- t i 0 - - ........ •• the top high • Olveoullnlen - -. - tt r -__ / 1 .-- ........ .I
